I host a copy of Little Brother and Homeland by Cory Doctorow because these books are too good to risk losing. These digital copies were downloaded from
Cory Doctorow's website, https://craphound.com/littlebrother/download/ and 
https://craphound.com/homeland/download/, where he has released them for
free. If you enjoy the books, you can support the author by buying a physical
copy of the book, which is available at many bookstores and also Amazon.

Each folder contains copies of the book in different formats. I find that
the epub format is the easiest to read, but other formats are available too.
Each file contains the entire book, the only difference is the format.


- Jeffrey Meng, jeffkmeng.com
This zip file was downloaded from:
https://pgp.jeffkmeng.com/Cory%20Doctorow%20-%20Little%20Brother%20and%20Homeland.zip