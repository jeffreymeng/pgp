I host a copy of Little Brother and Homeland by Cory Doctorow because I think his books
are able to show us a world that may not be so far away. I love these two books and
whatever happens I don't want to lose them. These digital copies were downloaded from
Cory Doctorow's website, https://craphound.com/littlebrother/download/ and 
https://craphound.com/homeland/download/, where he has released them for
free. If you enjoy the books, I urge you to support the author by buying a physical
copy of the book, which is avaliable at many bookstores and also Amazon.

Each folder contains copies of the book in different formats. I find that
the epub format is the easiest to read, but other formats are avaliable too.
Each file contains the entire book, the only difference is the format.


- Jeffrey Meng, jeffkmeng.com